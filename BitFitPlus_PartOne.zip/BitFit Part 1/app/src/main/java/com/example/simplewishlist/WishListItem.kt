package com.example.simplewishlist

// Contains an Item characteristics/ attributes

class WishListItem(
    var name: String,
    var calories: String,
    var time: String,)
